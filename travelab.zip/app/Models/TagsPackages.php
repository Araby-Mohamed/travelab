<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TagsPackages extends Model
{
    protected $table = 'tags_packages';

    protected $fillable = ['title','package_id'];

    public function packages(){
        return $this->belongsTo(Packages::class,'package_id','id');
    }
}
